#pragma once
#include "GooObject.h"


class Bullet : public GoodObject
{
	const float bulletSpeed = 15;

public:
	Bullet(Game* gam, double x = 0, double y = 0, int w_ = 20, int h_ = 5);
	~Bullet();

	void collidedWithSomthing();

private:
	//Para saber donde empieza
	float initPos;


	virtual void update();

	// Heredado v�a GoodObject
	virtual void draw() override;
	virtual void drawDebug();

};